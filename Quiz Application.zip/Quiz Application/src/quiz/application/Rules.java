package quiz.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Rules extends JFrame implements ActionListener{
    
    String name;
    JButton start,back;
    
    Rules(String name) {
        this.name = name;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel heading = new JLabel("Welcome " + name + " to the yellow quiz!");
        heading.setBounds(50, 20, 700, 30);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 28));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);
        
        JLabel rules = new JLabel();
        rules.setBounds(20, 90, 700, 350);
        rules.setFont(new Font("Tahoma", Font.PLAIN, 16));
        rules.setText("""
                      <html>1. The quiz consists of 10 questions based on basic Java programming concepts.<br>2. Each question has 4 options, out of which only one option is correct.<br>3. The time limit for each question is 15 seconds. Once the time is up, the answer will be automatically submitted.<br>4. You cannot go back to the previous question once you move on to the next question.<br>5. You can only submit the quiz after completing all 10 questions. You cannot submit the quiz in between.<br>6. There is a 50-50 lifeline available that you can use to eliminate two incorrect options.
                      Once you use this lifeline, only two options will remain, out of which one will be correct.<br>7. The lifeline can only be used once during the entire quiz.<br>8. Each correct answer will earn you 1 point. There is no negative marking for wrong answers or unanswered questions.<br>9. The final score will be displayed at the end of the quiz.<br><br><b>GOOD LUCK<b><br><br><html>""");
        add(rules);
        
        back = new JButton("Back");
        back.setBounds(250, 500, 100, 30);
        back.setBackground(new Color(30, 144, 254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);
        
        start = new JButton("Start");
        start.setBounds(400, 500, 100, 30);
        start.setBackground(new Color(30, 144, 254));
        start.setForeground(Color.WHITE);
        start.addActionListener(this);
        add(start);
        
        setSize(800, 650);
        setLocation(350, 100);
        setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == start) {
            setVisible(false);
            new Quiz(name);
        } else {
            setVisible(false);
            new Login();
        }
    }
    
    public static void main(String[] args) {
        new Rules("User");
    }
}
